document.addEventListener('DOMContentLoaded', function() {
    createBoard();
    createPlayerToken();
});

function createBoard() {
    const boardSize = 25; // Tamanho do tabuleiro
    const board = document.getElementById('board');

    for (let i = 0; i < boardSize; i++) {
        const square = document.createElement('div');
        square.classList.add('square');
        square.setAttribute('data-position', i);
        board.appendChild(square);
    }
}

function createPlayerToken() {
    const token = document.createElement('div');
    token.classList.add('token');
    token.style.backgroundColor = 'red'; // Cor do jogador
    document.querySelector('.square[data-position="0"]').appendChild(token); // Adiciona o token à posição inicial
}

let currentPosition = 0;

function rollDice() {
    const diceValue = Math.floor(Math.random() * 6) + 1;
    document.getElementById('dice').innerText = `Dado: ${diceValue}`;

    movePlayer(diceValue);
}

function movePlayer(steps) {
    const boardSize = 25; // Tamanho do tabuleiro
    const destination = 24; // Posição final de destino

    currentPosition += steps;
    if (currentPosition > boardSize) {
        currentPosition = boardSize;
    }

    // Se o jogador alcançar o destino
    if (currentPosition >= destination) {
        document.getElementById('dice').innerText = `Dado: ${steps} (Chegou ao destino!)`;
    }

    // Atualiza a posição visual do jogador no tabuleiro
    const token = document.querySelector('.token');
    const currentSquare = document.querySelector(`.square[data-position='${currentPosition}']`);
    currentSquare.appendChild(token);
}


